import 'dart:math';
import 'package:database_app/core/theme/app_colors.dart';
import 'package:flutter/material.dart';

class PunchRecordScreen extends StatelessWidget {
  final String? punchRecords;

  PunchRecordScreen({required this.punchRecords});

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    List<String> punches = punchRecords?.split(',') ?? [];

    return Scaffold(
      backgroundColor: Colors.white,
      //  backgroundColor : AppColor.mainBGColor,
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Records',
              style: TextStyle(
                  fontSize: height * 0.02,
                  color: AppColor.mainTextColor,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 15,
            ),
            SizedBox(
              height: height * 0.8,
              child: ListView.separated(
                itemCount: punches.length - 1,
                itemBuilder: (context, index) {
                  String punch = punches[index];
                  return Container(
                    height: height * 0.05,
                    width: width,
                    decoration: BoxDecoration(
                        color: AppColor.mainBGColor,
                        //   color: Colors.white,
                        borderRadius: BorderRadius.circular(5)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 10),
                      child: Row(
                        children: [
                          Text(
                            punch.substring(0, min(5, punch.length)),
                            style: TextStyle(
                              fontSize: height * 0.018,
                              color: punch.contains('in') ? Colors.green : Colors.red,
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                         
                          Icon(
                              punch.contains('in')
                                  ? Icons.trending_down
                                  : Icons.trending_up,
                              color: punch.contains('in')
                                  ? Colors.green
                                  : Colors.red),

                          // Padding(
                          //   padding: const EdgeInsets.symmetric(vertical: 5),
                          //   child: Image.asset(
                          //     punch.contains('in')
                          //         ? 'assets/image/in.png'
                          //         : 'assets/image/out.png',
                          //     // height: height * 0.09,
                          //   ),
                          // ),
                          // SizedBox(
                          //   width: 10,
                          // ),
                          // Text(
                          //   punch.substring(0, min(5, punch.length)),
                          //   style: TextStyle(
                          //     fontSize: height * 0.018,
                          //     color: punch.contains('in')
                          //         ? Colors.green
                          //         : Colors.red,
                          //   ),
                          // ),
                        ],
                        // subtitle: Text(punch.substring(6).replaceAll('(IN 1)', '').replaceAll('(OUT1)', '').replaceAll('(OUT)', '')),
                      ),
                    ),
                  );
                },
                separatorBuilder: (BuildContext context, int index) {
                  return SizedBox(
                    height: 10,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}