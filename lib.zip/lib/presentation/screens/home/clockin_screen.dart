import 'package:database_app/core/api/api.dart';
import 'package:database_app/core/model/models.dart';
import 'package:database_app/core/theme/app_colors.dart';
import 'package:database_app/presentation/screens/home/punch_records.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class ClockInScreen extends StatefulWidget {
  const ClockInScreen({super.key});
  @override
  State<ClockInScreen> createState() => _ClockInScreenState();
}

class _ClockInScreenState extends State<ClockInScreen> {
  String? empID;
  late Future<List<Attendance>> attendenceLog;

  @override
  void initState() {
    super.initState();
    // checkEmployeeId();
    attendenceLog = fetchAttendence();
  }

  // Future<void> checkEmployeeId() async {
  //   var box = await Hive.openBox('authBox');

  //   setState(() {
  //     empID = box.get('employeeId');
  //   });
  //   print('Stored Employee ID: $empID');
  // }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColor.mainBGColor,
        body: Stack(
          children: [
            Container(
              height: height * 0.25,
              width: width,
              decoration: BoxDecoration(   boxShadow: [
                              BoxShadow(
                                  spreadRadius: 2,
                                  blurRadius: 10,
                                  color: Colors.black.withOpacity(0.1),
                                  offset: Offset(0, 10))
                            ],
                  color: AppColor.mainThemeColor,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20))),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 25, vertical: 40),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          'Let’s Clock-In!',
                          style: TextStyle(
                              fontSize: height * 0.023,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          'Don’t miss your clock in schedule',
                          style: TextStyle(
                            fontSize: height * 0.018,
                            color: Colors.white,
                          ),
                        )
                      ],
                    ),
                    Image.asset(
                      'assets/image/clockinImage.png',
                      height: height * 0.09,
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  height: height * 0.68,
                  child: FutureBuilder<List<Attendance>>(
                    future: attendenceLog,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      } else if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return Center(
                            child: Text('No attendance records available.'));
                      } else {
                        List<Attendance> items = snapshot.data!;

                        return ListView.separated(
                          itemCount: items.length,
                          itemBuilder: (context, index) {
                            Attendance item = items[index];

                            DateTime dateTime = DateTime.parse(item.inTime);
                            DateTime dateTime2 = DateTime.parse(item.outTime);
                            Duration duration = dateTime2.difference(dateTime);

                            DateTime date =
                                DateTime.parse(item.attendanceDate);

                            String attendDate =
                                DateFormat('dd MMMM yyyy').format(date);

                            String punchIn =
                                "${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}";
                            String punchOut =
                                "${dateTime2.hour.toString().padLeft(2, '0')}:${dateTime2.minute.toString().padLeft(2, '0')}";

                            int hours = duration.inHours;
                            int minutes = duration.inMinutes % 60;

                            return InkWell(
                              onTap: () {
                                if (item.punchRecords.isNotEmpty) {
                                  showCupertinoModalBottomSheet(
                                    expand: true,
                                    context: context,
                                    barrierColor:
                                        const Color.fromARGB(130, 0, 0, 0),
                                    backgroundColor:
                                        const Color.fromARGB(0, 0, 0, 0),
                                    builder: (context) => PunchRecordScreen(
                                      punchRecords: item.punchRecords,
                                    ),
                                  );
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            'No punch records available for this date.')),
                                  );
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,   boxShadow: [
                              BoxShadow(
                                  spreadRadius: 2,
                                  blurRadius: 10,
                                  color: Colors.black.withOpacity(0.1),
                                  offset: Offset(0, 10))
                            ],
                                    borderRadius: BorderRadius.circular(7)),
                                child: Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '$attendDate',
                                        style: TextStyle(
                                            fontSize: height * 0.018,
                                            color: AppColor.mainTextColor,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    14, 0, 0, 0)),
                                            color: AppColor.mainBGColor,
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 7, vertical: 7),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'Total Hours',
                                                    style: TextStyle(
                                                      fontSize: height * 0.015,
                                                      color: AppColor
                                                          .mainTextColor2,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 3,
                                                  ),
                                                  Text(
                                                    hours == 0 && minutes == 0
                                                        ? '00:00'
                                                        : '0${hours.toString()}:${minutes.toString()}',
                                                    style: TextStyle(
                                                      fontSize: height * 0.023,
                                                      color: AppColor
                                                          .mainTextColor,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'Clock in & Out',
                                                    style: TextStyle(
                                                      fontSize: height * 0.015,
                                                      color: AppColor
                                                          .mainTextColor2,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 3,
                                                  ),
                                                  Text(
                                                    '$punchIn - $punchOut',
                                                    style: TextStyle(
                                                      fontSize: height * 0.023,
                                                      color: AppColor
                                                          .mainTextColor,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return SizedBox(
                              height: 10,
                            );
                          },
                        );
                      }
                    },
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
