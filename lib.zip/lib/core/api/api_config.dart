final url = 'http://172.23.100.121:3000';

final getAttendenceData = '$url/api/attendance-logs';
final getEmployeeData = '$url/api/employee/get-employee-details';
final employeeLogin = '$url/api/employee/login';
final getLeaveHistory = '$url/api/leave/get-employee-leave';
final employeeApplyLeave = '$url/api/leave/apply-leave';