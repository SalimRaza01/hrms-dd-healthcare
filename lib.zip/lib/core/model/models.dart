class ShiftTimeModel {
  final String startTime;
  final String endTime;

  ShiftTimeModel({required this.startTime, required this.endTime});

  factory ShiftTimeModel.fromJson(Map<String, dynamic> json) {
    return ShiftTimeModel(
      startTime: json['startAt'],
      endTime: json['endAt'],
    );
  }
}

class LeaveBalance {
  final String casualLeave;
  final String medicalLeave;
  final String earnedLeave;
  final String paternityLeave;
  final String maternityLeave;
  final String compOffLeave;

  LeaveBalance({
    required this.casualLeave,
    required this.medicalLeave,
    required this.earnedLeave,
    required this.paternityLeave,
    required this.maternityLeave,
    required this.compOffLeave,
  });

  factory LeaveBalance.fromJson(Map<String, dynamic> json) {
    return LeaveBalance(
      casualLeave: json['casualLeave'],
      medicalLeave: json['medicalLeave'],
      earnedLeave: json['earnedLeave'],
      paternityLeave: json['paternityLeave'],
      maternityLeave: json['maternityLeave'],
      compOffLeave: json['compOffLeave'],
    );
  }
}

class Employee {
  final String employeeName;
  final String employeeCode;
  final int employeeId;
  final String designation;
  final String doj;
  final String employmentType;
  final String address;
  final String contactNo;

  Employee({
    required this.employeeName,
    required this.employeeCode,
    required this.employeeId,
    required this.designation,
    required this.doj,
    required this.employmentType,
    required this.address,
    required this.contactNo,
  });

  factory Employee.fromJson(Map<String, dynamic> json) {
    return Employee(
      employeeName: json['employeeName'],
      employeeCode: json['employeeCode'],
      employeeId: json['employeeId'],
      designation: json['designation'],
      doj: json['doj'],
      employmentType: json['employmentType'],
      address: json['residentialAddress'],
      contactNo: json['contactNo'],
    );
  }
}

class Attendance {
  final String employeeName;
  final String employeeCode;
  final String gender;
  final String employmentType;
  final String attendanceDate;
  final String inTime;
  final String outTime;
  final String status;
  final int duration;
  final String punchRecords;

  Attendance({
    required this.employeeName,
    required this.employeeCode,
    required this.gender,
    required this.employmentType,
    required this.attendanceDate,
    required this.inTime,
    required this.outTime,
    required this.status,
    required this.duration,
    required this.punchRecords,
  });

  // Factory constructor to create an Attendance object from JSON
  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      employeeName: json['EmployeeName'] ?? '',
      employeeCode: json['EmployeeCode'] ?? '',
      gender: json['Gender'] ?? '',
      employmentType: json['EmployementType'] ?? '',
      attendanceDate: json['AttendanceDate'] ?? '',
      inTime: json['InTime'] ?? '',
      outTime: json['OutTime'] ?? '',
      status: json['Status'] ?? '',
      duration: json['Duration'] ?? 0,
      punchRecords: json['PunchRecords'] ?? '',
    );
  }

  // Convert Attendance object to JSON if needed
  Map<String, dynamic> toJson() {
    return {
      'EmployeeName': employeeName,
      'EmployeeCode': employeeCode,
      'Gender': gender,
      'EmployementType': employmentType,
      'AttendanceDate': attendanceDate,
      'InTime': inTime,
      'OutTime': outTime,
      'Status': status,
      'Duration': duration,
      'PunchRecords': punchRecords,
    };
  }
}

class LeaveHistory {
  final String id;
  final String leaveType;
  final String leaveStartDate;
  final String leaveEndDate;
  final String totalDays;
  final String reason;
  final String status;
  final String approvedBy;
  final String dateTime;

  LeaveHistory({
    required this.id,
    required this.leaveType,
    required this.leaveStartDate,
    required this.leaveEndDate,
    required this.totalDays,
    required this.reason,
    required this.status,
    required this.approvedBy,
    required this.dateTime,
  });

factory LeaveHistory.fromJson(Map<String, dynamic> json) {
  return LeaveHistory(
    id: json['_id'] ?? '',
    leaveType: json['leaveType'] ?? '',
    leaveStartDate: json['leaveStartDate'] ?? '',
    leaveEndDate: json['leaveEndDate'] ?? '',
    totalDays: json['totalDays'] ?? '',
    reason: json['reason'] ?? '',
    status: json['status'] ?? '', 
    approvedBy: json['approvedBy'] ?? '',
    dateTime: json['dateTime'] ?? '',
  );
}

  // Convert Attendance object to JSON if needed
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'leaveType': leaveType,
      'leaveStartDate': leaveStartDate,
      'leaveEndDate': leaveEndDate,
      'totalDays': totalDays,
      'reason': reason,
      'status': status,
      'approvedBy': approvedBy,
      'dateTime': dateTime,
    };
  }
}
